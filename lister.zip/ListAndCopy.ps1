function ListAndCopy {
    [CmdletBinding()]
    param (
        [string]$WorkingFolderParameter,
        [string[]]$ExcludedFolders,
        [string[]]$AllowedFiles
    )

    $sb = New-Object System.Text.StringBuilder
    $depth = 0

    function ProcessDirectory($path) {
        if ($ExcludedFolders -contains (Split-Path $path -Leaf)) { return }

        $depth++
        PrintListItem $path $null $true $depth $false 2 | Out-Null

        $files = Get-ChildItem -Path $path -File -Include $AllowedFiles
        foreach ($file in $files) {
            PrintListItem $file.FullName $null $false $depth $false 2 | Out-Null
            $null = $sb.AppendLine($file.FullName)
        }

        $subdirs = Get-ChildItem -Path $path -Directory
        foreach ($subdir in $subdirs) {
            ProcessDirectory $subdir.FullName
        }
        $depth--
    }

    ProcessDirectory $WorkingFolderParameter
    return $sb.ToString()
}
