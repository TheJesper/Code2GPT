function GetIndentation($level) {
    $indentation = ""
    for ($i = 0; $i -lt $level; $i++) {
        $indentation += "   "
    }
    return $indentation
}

function ListItems($path, $level, $output, $ExcludedFolders, $AllowedFiles, $WorkingFolderParameter) {
    $items = Get-ChildItem -Path $path
    foreach ($item in $items) {
        $exclude = $false
        foreach ($excludedFolder in $ExcludedFolders) {
            if ($item.FullName -match [regex]::Escape("\$excludedFolder\")) {
                $exclude = $true
                break
            }
        }
        if (!$exclude) {
            $relativePath = $item.FullName -ireplace [regex]::Escape($WorkingFolderParameter), ''
            $relativePath = $relativePath.TrimStart('\')
            if ($item -is [System.IO.DirectoryInfo]) {
                $output.Add("$(GetIndentation $level)📦$relativePath")
                ListItems -path $item.FullName -level ($level + 1) -output $output -ExcludedFolders $ExcludedFolders -AllowedFiles $AllowedFiles -WorkingFolderParameter $WorkingFolderParameter
            }
            elseif ($item -is [System.IO.FileInfo]) {
                foreach ($allowedFile in $AllowedFiles) {
                    if ($item.Name -like $allowedFile) {
                        $output.Add("$(GetIndentation $level)┣ 📜$($item.Name)")
                        break
                    }
                }
            }
        }
    }
}

function PrintListItem($Path, $Index, $IsFolder, $Depth, $ShowNumbers, $Spacing) {
    $spaces = " " * ($Depth * $Spacing)
    if ($ShowNumbers) {
        Write-Host -NoNewline "$spaces[$Index] "
    }
    $spaces = " " * ($Depth * $Spacing + 4)
    $fileFolderIcon = if ($IsFolder) { "📂" } else { "┣ 📄" }
    Write-Host "$spaces$fileFolderIcon $Path"
}
